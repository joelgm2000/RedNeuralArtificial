package org.math.plot.plotObjects;

/**
 * BSD License
 * 
 * @author Yann RICHET
 */

public interface BaseDependant {
	public void resetBase();
}